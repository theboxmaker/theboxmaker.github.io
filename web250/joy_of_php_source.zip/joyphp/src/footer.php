<?php
 echo "<br><br><a href='samsusedcars.html'>Sam's Used Cars Home</a>";
  echo "<br>Copyright 2017, Alan Forbes.  All rights reserved.";
?>