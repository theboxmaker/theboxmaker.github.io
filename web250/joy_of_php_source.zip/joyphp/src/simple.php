<html>
	<body>
		<h1>Variables</h1>	
		<?php
			echo "<br>";
			$brand="Ford";
			$model="Explorer";
			$year = 200;
			
			echo "This $brand $model is a $year <br>";
			$gas_price = 3.89;
			echo "the price of gas is $gas_price";
            echo "<br><br><a href='index.html'>Home</a>";
		?>
	</body>	
</html>

